const state = {
  vehicle: { id: "EV-KA01-2026", lat: 17.4445, lon: 78.3772, battery: 72, status: "Idle" },
  stations: [],
  evaluated: [],
  best: null,
  running: false,
  charging: false,
  routeIndex: 0,
  chargeTimer: null,
  movementTimer: null,
  locationTimer: null,
  liveGPS: false,
  emergencyShown: false,
  emergencyStation: null,
  exactDestination: null,
  lowBatteryPhoneTimer: null,
  lowBatteryPhoneAlertsActive: false,
  lowBatteryLastAlert: 0,
  atChargingStation: false,
  destinationLocked: false
};

// A short editable simulation route.
const SIM_ROUTE = [
  [17.4445,78.3772],[17.4453,78.3790],[17.4463,78.3812],[17.4473,78.3833],
  [17.4482,78.3853],[17.4490,78.3873],[17.4500,78.3892],[17.4512,78.3872],
  [17.4503,78.3848],[17.4491,78.3821],[17.4477,78.3796],[17.4462,78.3778]
];

let map, vehicleMarker, routeLine;
const stationMarkers = new Map();

const $ = id => document.getElementById(id);

let activeTileLayer = null;

function addLiveTileLayer() {
  // Primary map: OpenStreetMap, no API key required.
  const osm = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    minZoom: 2,
    attribution: "&copy; OpenStreetMap contributors",
    crossOrigin: true
  });

  // Fallback map: CARTO Voyager, also does not require an API key.
  const carto = L.tileLayer("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png", {
    maxZoom: 20,
    minZoom: 2,
    attribution: "&copy; OpenStreetMap contributors &copy; CARTO",
    subdomains: "abcd"
  });

  let fallbackStarted = false;
  osm.on("tileerror", () => {
    if (!fallbackStarted) {
      fallbackStarted = true;
      if (map.hasLayer(osm)) map.removeLayer(osm);
      activeTileLayer = carto.addTo(map);
      if ($("mapStatus")) $("mapStatus").textContent = "Live map • fallback tiles";
      addNotification("Map fallback", "OpenStreetMap tiles were unavailable, so fallback map tiles are being used.");
      setTimeout(() => map.invalidateSize(true), 100);
    }
  });

  activeTileLayer = osm.addTo(map);
  return osm;
}

function initMap() {
  map = L.map("map", {
    zoomControl: true,
    preferCanvas: true,
    worldCopyJump: true
  }).setView([state.vehicle.lat, state.vehicle.lon], 14);

  addLiveTileLayer();

  vehicleMarker = L.marker([state.vehicle.lat, state.vehicle.lon], {
    icon: L.divIcon({
      className:"vehicle-icon",
      html:"🚗",
      iconSize:[30,30],
      iconAnchor:[15,15]
    })
  }).addTo(map).bindPopup(`<b>${state.vehicle.id}</b><br>Current vehicle`);

  renderVehicle();

  // Important when the map is inside a responsive/grid layout.
  setTimeout(() => map.invalidateSize(true), 150);
  setTimeout(() => map.invalidateSize(true), 700);
  window.addEventListener("resize", () => map.invalidateSize(true));
}

async function loadStations() {
  const res = await fetch("/api/stations");
  state.stations = await res.json();
  renderStations();
  await reverseGeocode(state.vehicle.lat, state.vehicle.lon);
  findBest(false);
}

function renderStations() {
  stationMarkers.forEach(m => map.removeLayer(m));
  stationMarkers.clear();

  state.stations.forEach(s => {
    const marker = L.marker([s.lat,s.lon], {
      icon: L.divIcon({className:"station-icon", html:"⚡", iconSize:[28,28], iconAnchor:[14,14]})
    }).addTo(map);

    marker.bindPopup(`
      <div class="station-popup"><b>${s.name}</b><br>
      ${s.charger_type} • ${s.speed_kw} kW<br>
      Slots: ${s.available_slots}/${s.total_slots}<br>
      Charge time: ${s.charging_minutes} min<br>
      Guard: ${s.guard ? "Available" : "Unavailable"}
      </div>`);

    // Small always-visible station name box on the map.
    marker.bindTooltip(s.name, {
      permanent: true,
      direction: "right",
      offset: [10, 0],
      className: "station-name-label"
    });
    stationMarkers.set(s.id, marker);
  });
}

function renderVehicle() {
  $("batteryText").textContent = `${Math.round(state.vehicle.battery)}%`;
  $("batteryBar").style.width = `${Math.max(0,state.vehicle.battery)}%`;
  $("coords").textContent = `${state.vehicle.lat.toFixed(5)}, ${state.vehicle.lon.toFixed(5)}`;
  $("vehicleStatus").textContent = state.charging ? "Charging" : state.vehicle.status;
  $("movementState").textContent = state.liveGPS ? "Live GPS" : (state.running ? "Moving" : "Ready");

  let label = "Healthy";
  if (state.vehicle.battery <= 20) label = "Low battery";
  if (state.vehicle.battery <= 10) label = "Critical battery";
  $("batteryState").textContent = label;
  if ($("vehicleId")) $("vehicleId").textContent = state.vehicle.id;
  if ($("rangeText")) $("rangeText").textContent = `${Math.round(state.vehicle.battery * 2)} km`;

  vehicleMarker.setLatLng([state.vehicle.lat,state.vehicle.lon]);
}

async function reverseGeocode(lat, lon) {
  try {
    const res = await fetch("/api/reverse-geocode", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({lat,lon})
    });
    const data = await res.json();
    $("locationName").textContent = data.name || "Unknown location";
  } catch {
    $("locationName").textContent = `${lat.toFixed(5)}, ${lon.toFixed(5)}`;
  }
}

let lastGeocode = 0;
async function updateLocation(lat, lon, isLive=false) {
  // Once the vehicle has arrived at a requested station, keep it there until the user
  // explicitly starts another navigation/reset. GPS/simulation updates must not pull it back.
  if (state.destinationLocked && !state.running && !state.charging) return;
  state.vehicle.lat = lat;
  state.vehicle.lon = lon;
  state.liveGPS = isLive;
  renderVehicle();
  map.panTo([lat,lon], {animate:true, duration:.3});

  // Avoid excessive geocoding requests during simulation.
  const now = Date.now();
  if (isLive || now-lastGeocode > 12000) {
    lastGeocode = now;
    reverseGeocode(lat,lon);
  }
  await findBest(false);
}

async function findBest(showNotice=true) {
  const res = await fetch("/api/recommend", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify(state.vehicle)
  });
  const data = await res.json();
  state.evaluated = data.evaluated;
  state.best = data.best;
  // Do not replace a user-selected navigation destination while the car is driving to it.
  if (!state.running && !state.atChargingStation) state.exactDestination = data.best;

  renderTable();
  renderRecommendation(data);
  drawRecommendationRoute();

  if (showNotice && state.best) {
    addNotification("Recommendation", `${state.best.name} selected with score ${state.best.score}.`);
  }
  checkBatteryAlerts();
}

function renderTable() {
  const sortMode = $("sortSelect") ? $("sortSelect").value : "score";
  const list = [...state.evaluated];
  if (sortMode === "distance") list.sort((a,b)=>a.distance_km-b.distance_km);
  else if (sortMode === "time") list.sort((a,b)=>a.charging_minutes-b.charging_minutes);
  else if (sortMode === "availability") list.sort((a,b)=>b.available_slots-a.available_slots);
  else list.sort((a,b)=>b.score-a.score);

  const rows = list.map((s,i)=>{
    const score = Math.max(0, Number(s.score)||0);
    const range = s.feasible ? "" : `<span class="range-pill">out of range</span>`;
    return `<tr data-station-id="${s.id}">
      <td>${i+1}</td>
      <td><b>${s.name}</b>${range}</td>
      <td>${s.distance_km} km</td>
      <td><span class="availability-pill ${s.available_slots ? "available":"full"}">${s.available_slots ? "Available":"Full"} ${s.available_slots}/${s.total_slots}</span></td>
      <td><span class="charger-pill">${s.charger_type.replace(" Charger","")} · ${s.speed_kw}kW</span></td>
      <td>${s.charging_minutes} min</td>
      <td><span class="guard-pill ${s.guard ? "yes":"no"}">${s.guard ? "♢ Yes":"♢ No"}</span></td>
      <td>${s.distance_score.toFixed(1)}</td>
      <td>${s.availability_score.toFixed(1)}</td>
      <td>${s.charging_score.toFixed(1)}</td>
      <td>${s.battery_score.toFixed(1)}</td>
      <td>${s.charger_score.toFixed(1)}</td>
      <td class="score-cell">${score.toFixed(0)}</td>
    </tr>`;
  }).join("");
  $("stationTable").innerHTML = rows;

  document.querySelectorAll("#stationTable tr").forEach(row=>{
    row.addEventListener("click",()=>{
      document.querySelectorAll("#stationTable tr").forEach(r=>r.classList.remove("selected"));
      row.classList.add("selected");
      const station = state.evaluated.find(s=>s.id===row.dataset.stationId);
      if (station) selectStation(station);
    });
  });
}

function selectStation(station) {
  state.best = station;
  renderRecommendation({best:station, reason:[
    `${station.distance_km} km from the vehicle`,
    `${station.available_slots}/${station.total_slots} slots available`,
    `${station.charger_type} at ${station.speed_kw} kW`,
    `estimated charging time ${station.charging_minutes} minutes`,
    station.guard ? "guard available" : "no guard currently available"
  ]});
  drawRecommendationRoute();
  if (stationMarkers.has(station.id)) {
    stationMarkers.get(station.id).openPopup();
  }
}
function renderRecommendation(data) {
  if (!data.best) {
    $("recommendationEmpty").textContent = "No suitable charging station is currently available.";
    $("recommendationEmpty").classList.remove("hidden");
    $("recommendationContent").classList.add("hidden");
    return;
  }
  const b=data.best;
  $("recommendationEmpty").classList.add("hidden");
  $("recommendationContent").classList.remove("hidden");
  $("bestName").textContent = b.name;
  $("bestScore").textContent = b.score;
  $("bestDistance").textContent = `${b.distance_km} km`;
  $("bestCharger").textContent = `${b.charger_type.replace(" Charger","")} · ${b.speed_kw}kW`;
  $("bestTime").textContent = `${b.charging_minutes} min`;
  $("bestGuard").textContent = b.guard ? "Guard Available" : "Guard Unavailable";
  $("bestSlots").textContent = `${b.available_slots}/${b.total_slots}`;
  $("bestTravel").textContent = `${Math.max(1,Math.ceil(b.distance_km / 0.5))} min`;
  $("reasonList").innerHTML = data.reason.map(x=>`<li>${x}</li>`).join("");
}

function drawRecommendationRoute() {
  if (routeLine) map.removeLayer(routeLine);
  if (!state.best) return;
  routeLine = L.polyline([
    [state.vehicle.lat,state.vehicle.lon],
    [state.best.lat,state.best.lon]
  ], {color:"#28d7ff", weight:5, dashArray:"9 8"}).addTo(map);

  stationMarkers.forEach((marker,id)=>{
    marker.setOpacity(id===state.best.id ? 1 : .72);
  });
}

function addNotification(title, message) {
  const div=document.createElement("div");
  div.className="notice";
  div.innerHTML=`<b>${title}</b><span>${message} • ${new Date().toLocaleTimeString()}</span>`;
  $("notifications").prepend(div);
}

function showAlert(text) {
  $("alertBanner").textContent=text;
  $("alertBanner").classList.remove("hidden");
}
function hideAlert(){ $("alertBanner").classList.add("hidden"); }


function sendSimulatedPhoneMessage() {
  if (state.vehicle.battery <= 0) return;

  const level = Math.round(state.vehicle.battery);
  const message = level <= 10
    ? `DEMO PHONE MESSAGE: Critical Battery – ${level}% remaining. Charging station recommended immediately.`
    : `DEMO PHONE MESSAGE: Low Battery – ${level}% remaining. Find a charging station.`;

  addNotification("📱 Phone Alert (SIMULATED)", message);
}


async function sendLowBatteryMobileAlert() {
  if (state.vehicle.battery > 20 || !state.lowBatteryPhoneAlertsActive) return;
  const location = $("locationName") ? $("locationName").textContent : `${state.vehicle.lat.toFixed(5)}, ${state.vehicle.lon.toFixed(5)}`;
  const station = state.best ? state.best.name : "nearest suitable station";
  try {
    const res = await fetch("/api/low-battery-alert", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({battery:state.vehicle.battery, location, station})
    });
    const data = await res.json();
    if (data.success) addNotification("📱 Registered mobile alert", data.message);
    else if (res.status === 401) window.location.href="/login";
  } catch(e) {
    addNotification("Mobile alert error", "Could not contact the alert service.");
  }
}

function startLowBatteryPhoneAlerts() {
  if (state.lowBatteryPhoneAlertsActive || state.vehicle.battery <= 0) return;

  state.lowBatteryPhoneAlertsActive = true;
  const badge = $("phoneAlertBadge");
  const text = $("phoneAlertText");
  if (badge) { badge.textContent = "ACTIVE • EVERY 2 MIN"; badge.className = "badge phone-active"; }
  if (text) text.textContent = "SIMULATED phone messages are sent every 2 minutes while battery is 20% or below.";
  sendSimulatedPhoneMessage();
  sendLowBatteryMobileAlert();

  // Registered-mobile alert repeats every 2 minutes.
  state.lowBatteryPhoneTimer = setInterval(() => {
    if (state.vehicle.battery > 0 && state.vehicle.battery <= 20) {
      sendSimulatedPhoneMessage();
      sendLowBatteryMobileAlert();
    } else {
      stopLowBatteryPhoneAlerts();
    }
  }, 120000);

  addNotification(
    "📱 Phone alert service",
    "Low-battery phone messages are now simulated every 2 minutes until the battery is above 20% or reaches 0%."
  );
}

function stopLowBatteryPhoneAlerts() {
  if (state.lowBatteryPhoneTimer) {
    clearInterval(state.lowBatteryPhoneTimer);
    state.lowBatteryPhoneTimer = null;
  }
  state.lowBatteryPhoneAlertsActive = false;
  const badge = $("phoneAlertBadge");
  const text = $("phoneAlertText");
  if (badge) { badge.textContent = "INACTIVE"; badge.className = "badge blue"; }
  if (text) text.textContent = "Inactive — messages start automatically when battery reaches 20% or below.";
}

function checkBatteryAlerts() {
  if (state.vehicle.battery === 0) {
    stopLowBatteryPhoneAlerts();
    showAlert("🚨 EMERGENCY: Vehicle battery has reached 0%.");
    return;
  }

  if (state.vehicle.battery <= 10) {
    showAlert("🔴 Critical Battery – Charging station recommended immediately.");
    startLowBatteryPhoneAlerts();
  } else if (state.vehicle.battery <= 20) {
    showAlert("⚠️ Low Battery – Find a charging station.");
    startLowBatteryPhoneAlerts();
  } else {
    hideAlert();
    stopLowBatteryPhoneAlerts();
  }
}

async function notifyGuard() {
  if (!state.best || !state.best.guard) return;
  const res=await fetch("/api/notify-guard",{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({station_name:state.best.name})});
  const data=await res.json();
  addNotification("Guard notification", data.message);
}


async function findNearestForEmergency() {
  const res = await fetch("/api/nearest", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify(state.vehicle)
  });
  const data = await res.json();
  state.emergencyStation = data.station;
  return data.station;
}

async function triggerEmergency() {
  if (state.vehicle.battery !== 0) return;

  state.running = false;
  state.charging = false;
  clearInterval(state.movementTimer);
  clearInterval(state.chargeTimer);
  state.vehicle.status = "Idle";
  state.emergencyShown = true;

  const station = await findNearestForEmergency();

  $("emergencyBattery").textContent = "0%";
  $("emergencyLocation").textContent = $("locationName").textContent || `${state.vehicle.lat.toFixed(5)}, ${state.vehicle.lon.toFixed(5)}`;
  $("emergencyStation").textContent = station ? station.name : "No station found";
  $("emergencyDistance").textContent = station ? `${station.distance_km} km` : "--";
  $("emergencySlot").textContent = station ? `${station.available_slots}/${station.total_slots} ${station.available_slots > 0 ? "(Available)" : "(Full)"}` : "--";
  $("emergencyCharger").textContent = station ? station.charger_type : "--";
  $("emergencyGuard").textContent = station ? (station.guard ? "Available" : "Unavailable") : "--";

  $("emergencyOverlay").classList.remove("hidden");
  showAlert("🚨 EMERGENCY: Vehicle battery has reached 0%.");
  addNotification("🚨 EMERGENCY", "Vehicle battery has reached 0%. Emergency assistance workflow started.");
  addNotification("📱 DEMO SMS / MESSAGE", station
    ? `SIMULATED emergency phone message: vehicle needs help near ${$("locationName").textContent}. Nearest station: ${station.name}.`
    : "SIMULATED emergency phone message: vehicle battery is at 0% and needs assistance.");

  if (station && station.guard) {
    notifyGuard();
  }

  if (station) {
    drawEmergencyRoute(station);
  }
  renderVehicle();
}

function drawEmergencyRoute(station) {
  if (!station) return;
  if (routeLine) map.removeLayer(routeLine);
  routeLine = L.polyline([
    [state.vehicle.lat,state.vehicle.lon],
    [station.lat,station.lon]
  ], {color:"#ff5c69", weight:6, dashArray:"7 6"}).addTo(map);
  map.fitBounds(routeLine.getBounds(), {padding:[30,30]});
}

function setBatteryZero() {
  state.vehicle.battery = 0;
  renderVehicle();
  checkBatteryAlerts();
  findBest(false).finally(() => triggerEmergency());
}

function closeEmergency() {
  $("emergencyOverlay").classList.add("hidden");
}

function getHelp() {
  $("emergencyMessage").textContent = "Help request sent successfully. Nearest station/guard has been notified. (DEMO simulation)";
  addNotification("🆘 Help request", "Simulated help request sent successfully.");
  if (state.emergencyStation && state.emergencyStation.guard) notifyGuard();
}


function moveVehicleToNavigationSpot() {
  const destination = state.exactDestination || state.best;
  if (!destination) {
    addNotification("Vehicle Navigation", "Select a charging station first.");
    return;
  }

  const start = [Number(state.vehicle.lat), Number(state.vehicle.lon)];
  const target = [Number(destination.lat), Number(destination.lon)];
  if (![...start,...target].every(Number.isFinite)) return;

  // Keep this destination locked until arrival.
  state.exactDestination = destination;
  state.atChargingStation = false;
  state.destinationLocked = false;

  // Stop any previous GPS polling so it cannot move the marker back after arrival.
  clearInterval(state.locationTimer);
  state.locationTimer = null;

  const rawRoute = state.navigationRoute && state.navigationRoute.length > 1
    ? state.navigationRoute.map(p => [Number(p[0]), Number(p[1])])
    : [start, target];

  // Fast demo movement: keep the real road shape, but compress a long OSRM
  // route to a small number of animation points so the car reaches the
  // station quickly instead of taking one timer tick per GPS point.
  const MAX_ANIMATION_POINTS = 70;
  const route = rawRoute.length <= MAX_ANIMATION_POINTS
    ? rawRoute
    : Array.from({length: MAX_ANIMATION_POINTS}, (_, i) => {
        const pos = i * (rawRoute.length - 1) / (MAX_ANIMATION_POINTS - 1);
        return rawRoute[Math.round(pos)];
      });

  clearInterval(state.movementTimer);
  state.running = true;
  state.charging = false;
  state.vehicle.status = "Moving";
  renderVehicle();
  addNotification("🚗 Driving to station", `Moving to ${destination.name}.`);

  let idx = 0;
  state.movementTimer = setInterval(() => {
    if (idx >= route.length) {
      clearInterval(state.movementTimer);
      state.movementTimer = null;
      state.running = false;
      state.vehicle.status = "Idle";
      state.vehicle.lat = target[0];
      state.vehicle.lon = target[1];
      state.best = destination;
      state.exactDestination = destination;
      state.atChargingStation = true;
      state.destinationLocked = true;
      // Absolutely stop all movement sources at the exact destination.
      clearInterval(state.locationTimer);
      state.locationTimer = null;
      clearInterval(state.movementTimer);
      state.movementTimer = null;
      renderVehicle();
      reverseGeocode(target[0], target[1]);
      map.flyTo(target, 18, {animate:true, duration:1});
      if (stationMarkers.has(destination.id)) stationMarkers.get(destination.id).openPopup();
      addNotification("📍 Arrived at exact spot", `${destination.name}. You can now click Charge.`);
      renderRecommendation({best:destination, reason:[
        "Vehicle is at the exact station location",
        `${destination.available_slots}/${destination.total_slots} slots available`,
        `${destination.charger_type} at ${destination.speed_kw} kW`,
        `estimated charging time ${destination.charging_minutes} minutes`
      ]});
      return;
    }

    const point = route[idx++];
    state.vehicle.lat = point[0];
    state.vehicle.lon = point[1];
    // Update only the vehicle/map here; do not re-run recommendation and change the destination.
    renderVehicle();
    map.panTo(point, {animate:false});
    if (idx % 8 === 0) reverseGeocode(point[0], point[1]);
  }, 55);
}

function moveVehicle() {
  if (!state.running || state.charging || state.liveGPS) return;
  const p=SIM_ROUTE[state.routeIndex % SIM_ROUTE.length];
  state.routeIndex++;
  state.vehicle.status="Moving";
  state.vehicle.battery=Math.max(0,state.vehicle.battery-0.8);
  updateLocation(p[0],p[1],false);
  if (state.vehicle.battery === 0) {
    triggerEmergency();
    return;
  }
  if (state.vehicle.battery <= 10) {
    state.running=false;
    state.vehicle.status="Idle";
    addNotification("Safety stop","Simulation paused because battery reached a critical level.");
  }
}

function startVehicle() {
  if (state.charging) return;
  state.destinationLocked = false;
  state.liveGPS=false;
  state.running=true;
  state.vehicle.status="Moving";
  addNotification("Vehicle started","Simulation movement and battery monitoring enabled.");
  clearInterval(state.movementTimer);
  state.movementTimer=setInterval(moveVehicle,1800);
  moveVehicle();
}
function stopVehicle() {
  state.running=false;
  clearInterval(state.locationTimer);
  state.locationTimer=null;
  state.vehicle.status="Idle";
  clearInterval(state.movementTimer);
  renderVehicle();
  addNotification("Vehicle stopped","Simulation vehicle is idle.");
}

function useLiveLocation() {
  if (!navigator.geolocation) {
    addNotification("GPS unavailable","This browser does not support geolocation.");
    return;
  }
  stopVehicle();
  navigator.geolocation.getCurrentPosition(
    pos=>{
      updateLocation(pos.coords.latitude,pos.coords.longitude,true);
      $("mapMode").textContent="Live GPS";
      addNotification("Live location", "Vehicle location updated from browser GPS.");
    },
    err=>addNotification("GPS permission", err.message),
    {enableHighAccuracy:true, timeout:10000, maximumAge:5000}
  );
  clearInterval(state.locationTimer);
  state.locationTimer=setInterval(()=>{
    navigator.geolocation.getCurrentPosition(pos=>{
      updateLocation(pos.coords.latitude,pos.coords.longitude,true);
    },()=>{}, {enableHighAccuracy:true,timeout:8000,maximumAge:5000});
  },10000);
}

function changeBattery(delta) {
  state.vehicle.battery=Math.max(0,Math.min(100,state.vehicle.battery+delta));
  renderVehicle();
  if (state.vehicle.battery > 20) stopLowBatteryPhoneAlerts();
  checkBatteryAlerts();
  findBest(false);
}

function startCharging() {
  closeEmergency();
  const destination = state.exactDestination || state.best;

  if (!destination) {
    addNotification("Charging", "Select a charging station first.");
    return;
  }

  if (state.running) {
    addNotification("Charging locked", "Vehicle is still moving. Wait until it reaches the exact station spot.");
    return;
  }

  if (!state.atChargingStation) {
    addNotification("Charging locked", `Drive to ${destination.name} first using Go to Exact Spot.`);
    return;
  }

  if (state.vehicle.lat === undefined || state.vehicle.lon === undefined ||
      Math.abs(Number(state.vehicle.lat) - Number(destination.lat)) > 0.00012 ||
      Math.abs(Number(state.vehicle.lon) - Number(destination.lon)) > 0.00012) {
    state.atChargingStation = false;
    addNotification("Charging locked", "Vehicle is not at the exact charging location yet.");
    return;
  }

  if (!destination.available_slots) {
    addNotification("Charging unavailable", "Selected station is currently full.");
    return;
  }

  state.best = destination;
  state.running = false;
  state.charging = true;
  state.vehicle.status = "Charging";
  addNotification("⚡ Charging started", `${destination.name} — battery will charge now.`);
  renderVehicle();
  clearInterval(state.chargeTimer);
  state.chargeTimer=setInterval(()=>{
    state.vehicle.battery=Math.min(100,state.vehicle.battery+2);
    renderVehicle();
    if (state.vehicle.battery>=100) completeCharging();
  },700);
}

function completeCharging() {
  clearInterval(state.chargeTimer);
  stopLowBatteryPhoneAlerts();
  state.charging=false;
  state.vehicle.status="Idle";
  state.vehicle.battery=100;
  hideAlert();
  renderVehicle();
  addNotification("Charging completed","Battery reached 100%.");
}


function resetSimulation() {
  // Stop every active simulation/timer.
  state.running = false;
  state.charging = false;
  state.liveGPS = false;
  state.emergencyShown = false;
  state.emergencyStation = null;
  state.exactDestination = null;
  state.navigationRoute = null;
  state.atChargingStation = false;
  state.destinationLocked = false;
  state.routeIndex = 0;

  clearInterval(state.movementTimer);
  clearInterval(state.chargeTimer);
  clearInterval(state.locationTimer);
  stopLowBatteryPhoneAlerts();

  // Restore original demo vehicle state.
  state.vehicle.lat = 17.4445;
  state.vehicle.lon = 78.3772;
  state.vehicle.battery = 72;
  state.vehicle.status = "Idle";

  if (routeLine) {
    map.removeLayer(routeLine);
    routeLine = null;
  }
  if (window.exactSpotMarker) {
    map.removeLayer(window.exactSpotMarker);
    window.exactSpotMarker = null;
  }

  $("emergencyOverlay").classList.add("hidden");
  $("mapMode").textContent = "Simulation Mode";

  renderVehicle();
  hideAlert();

  addNotification("↻ Simulation reset", "Vehicle, battery, map route and alerts returned to the initial demo state.");

  map.setView([state.vehicle.lat, state.vehicle.lon], 14);
  reverseGeocode(state.vehicle.lat, state.vehicle.lon);
  findBest(false);
}

$("startBtn").onclick=()=>{
  if(state.exactDestination || state.best) moveVehicleToNavigationSpot();
  else startVehicle();
};
$("stopBtn").onclick=stopVehicle;
$("resetBtn").onclick=resetSimulation;
$("incBtn").onclick=()=>changeBattery(5);
$("decBtn").onclick=()=>changeBattery(-5);
$("zeroBtn").onclick=setBatteryZero;
$("findBtn").onclick=()=>findBest(true);
$("recommendChargeBtn").onclick=startCharging;
$("notifyGuardBtn").onclick=notifyGuard;

async function goToExactSpot() {
  const destination = state.exactDestination || state.best;
  if (!destination) {
    addNotification("📍 Go to Exact Spot", "Select a charging station first.");
    return;
  }

  const lat = Number(destination.lat);
  const lon = Number(destination.lon);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
    addNotification("📍 Go to Exact Spot", "The selected station has no valid coordinates.");
    return;
  }

  state.exactDestination = destination;
  state.best = destination;
  state.atChargingStation = false;
  state.destinationLocked = false;
  clearInterval(state.locationTimer);
  state.locationTimer = null;

  if (window.exactSpotMarker) map.removeLayer(window.exactSpotMarker);
  window.exactSpotMarker = L.circleMarker([lat, lon], {
    radius: 11, color: "#b4ff3c", weight: 3, fillColor: "#b4ff3c", fillOpacity: 0.30
  }).addTo(map).bindTooltip("EXACT SPOT", {
    permanent: true, direction: "top", className: "exact-spot-label", offset: [0, -8]
  });

  const marker = stationMarkers.get(destination.id);
  if (marker) marker.setZIndexOffset(3000);

  // Go to Spot now means: move the car to the exact station, not just the map camera.
  addNotification("📍 Go to Exact Spot", `Driving to ${destination.name} (${lat.toFixed(6)}, ${lon.toFixed(6)}).`);
  moveVehicleToNavigationSpot();
}

$("navigateBtn").onclick = async () => {
  const destination = state.best || state.exactDestination;

  if (!destination) {
    addNotification("Navigation", "Find a charging station first.");
    return;
  }

  state.exactDestination = destination;

  const startLat = Number(state.vehicle.lat);
  const startLon = Number(state.vehicle.lon);
  const endLat = Number(destination.lat);
  const endLon = Number(destination.lon);

  if (![startLat,startLon,endLat,endLon].every(Number.isFinite)) {
    addNotification("Navigation", "Vehicle or station coordinates are invalid.");
    return;
  }

  map.stop();
  const marker = stationMarkers.get(destination.id);
  if (marker) marker.setZIndexOffset(2500);

  try {
    const response = await fetch("/api/route", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        start_lat:startLat,
        start_lon:startLon,
        end_lat:endLat,
        end_lon:endLon
      })
    });
    const route = await response.json();

    if (route.success && route.coordinates && route.coordinates.length > 1) {
      state.navigationRoute = route.coordinates;

      if (routeLine) map.removeLayer(routeLine);
      routeLine=L.polyline(route.coordinates,{
        color:"#b4ff3c",
        weight:7,
        opacity:.95,
        lineCap:"round",
        lineJoin:"round"
      }).addTo(map);

      map.fitBounds(routeLine.getBounds(),{padding:[50,50],maxZoom:17,animate:true});

      addNotification(
        "⌁ Navigation",
        `Route to ${destination.name}: ${route.distance_km} km • ${route.duration_min} min.`
      );
    } else {
      // Straight-line fallback to the exact station coordinates.
      drawRecommendationRoute();
      map.fitBounds([[startLat,startLon],[endLat,endLon]],{padding:[50,50],maxZoom:17});
      addNotification("⌁ Navigation", `Exact destination set: ${destination.name}.`);
    }
  } catch (error) {
    drawRecommendationRoute();
    map.fitBounds([[startLat,startLon],[endLat,endLon]],{padding:[50,50],maxZoom:17});
    addNotification("⌁ Navigation", `Exact destination set: ${destination.name}.`);
  }

  // Make the separate exact-spot control obvious after navigation.
  const goBtn=$("goSpotBtn");
  if(goBtn){
    goBtn.classList.add("spot-ready");
    goBtn.textContent="📍 Go to Exact Spot";
  }
};
$("sortSelect").onchange=()=>renderTable();
$("completeBtn").onclick=completeCharging;
$("liveLocationBtn").onclick=useLiveLocation;
$("clearNotifications").onclick=()=>$("notifications").innerHTML="";
$("getHelpBtn").onclick=getHelp;
$("closeEmergencyBtn").onclick=closeEmergency;

$("logoutBtn")?.addEventListener("click", async () => {
  await fetch("/api/logout", {method:"POST"});
  window.location.href="/login";
});

$("goSpotBtn")?.addEventListener("click", goToExactSpot);

initMap();
loadStations();
