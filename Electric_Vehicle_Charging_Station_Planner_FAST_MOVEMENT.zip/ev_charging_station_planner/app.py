from flask import Flask, render_template, jsonify, request, session, redirect, url_for
import math
import heapq
import requests
from datetime import datetime
import os
import random
import time

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "ev-planner-demo-secret-change-me")

# Prototype OTP store. For production, use Redis/database and an expiry mechanism.
OTP_STORE = {}
OTP_EXPIRY_SECONDS = 300

def normalize_mobile(value):
    digits = "".join(ch for ch in (value or "") if ch.isdigit())
    if digits.startswith("91") and len(digits) == 12:
        return "+" + digits
    if len(digits) == 10:
        return "+91" + digits
    return None

def send_sms(phone, message):
    """Send real SMS when Twilio environment variables exist; otherwise simulate safely."""
    sid = os.environ.get("TWILIO_ACCOUNT_SID")
    token = os.environ.get("TWILIO_AUTH_TOKEN")
    from_number = os.environ.get("TWILIO_FROM_NUMBER")

    if sid and token and from_number:
        try:
            from twilio.rest import Client
            Client(sid, token).messages.create(body=message, from_=from_number, to=phone)
            return {"sent": True, "mode": "real"}
        except Exception as exc:
            return {"sent": False, "mode": "error", "error": str(exc)}

    return {"sent": False, "mode": "demo", "message": message}


# Sample stations are intentionally easy to edit.
STATIONS = [
    {
        "id": "ST01", "name": "HITEC City Fast Charge",
        "lat": 17.4474, "lon": 78.3762, "available_slots": 2, "total_slots": 4,
        "charger_type": "Fast Charger", "speed_kw": 60, "charging_minutes": 25,
        "guard": True
    },
    {
        "id": "ST02", "name": "Madhapur EV Hub",
        "lat": 17.4486, "lon": 78.3908, "available_slots": 1, "total_slots": 4,
        "charger_type": "CCS", "speed_kw": 50, "charging_minutes": 30,
        "guard": True
    },
    {
        "id": "ST03", "name": "Gachibowli Green Charge",
        "lat": 17.4401, "lon": 78.3489, "available_slots": 3, "total_slots": 6,
        "charger_type": "Type 2", "speed_kw": 22, "charging_minutes": 55,
        "guard": False
    },
    {
        "id": "ST04", "name": "Kondapur Power Point",
        "lat": 17.4598, "lon": 78.3651, "available_slots": 0, "total_slots": 4,
        "charger_type": "Normal Charger", "speed_kw": 11, "charging_minutes": 75,
        "guard": True
    },
    {
        "id": "ST05", "name": "Financial District Charge Park",
        "lat": 17.4217, "lon": 78.3432, "available_slots": 2, "total_slots": 5,
        "charger_type": "Fast Charger", "speed_kw": 80, "charging_minutes": 20,
        "guard": True
    },
]

# ---------- DAA / distance functions ----------

def haversine_km(lat1, lon1, lat2, lon2):
    """Great-circle distance. O(1) per station."""
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dlambda/2)**2
    return 2 * r * math.asin(math.sqrt(a))

def evaluate_station(station, vehicle):
    """
    Multi-factor DAA scoring.
    Total = distance + availability + charging time + battery safety + charger type.
    Higher is better. A station with no slot is strongly penalized.
    """
    distance = haversine_km(vehicle["lat"], vehicle["lon"], station["lat"], station["lon"])

    # Assumptions for a prototype:
    # EV consumes ~0.20 kWh/km and has a 50 kWh usable battery.
    battery = max(0, min(100, vehicle["battery"]))
    usable_kwh = 50.0
    consumption = 0.20
    required_pct = ((distance * consumption) / usable_kwh) * 100
    safety_margin = 5.0

    if battery >= required_pct + safety_margin:
        battery_score = 20
    elif battery >= required_pct:
        battery_score = 8
    else:
        battery_score = -40

    availability_score = 20 if station["available_slots"] > 0 else -50
    distance_score = max(0, 25 - distance * 4)

    # Lower charging time is better.
    charging_score = max(0, 20 - station["charging_minutes"] * 0.20)

    charger_points = {
        "Fast Charger": 15,
        "CCS": 14,
        "Type 2": 10,
        "Normal Charger": 7
    }
    charger_score = charger_points.get(station["charger_type"], 5)

    guard_score = 5 if station["guard"] else 0
    total = distance_score + availability_score + charging_score + battery_score + charger_score + guard_score

    feasible = battery >= required_pct + safety_margin and station["available_slots"] > 0

    return {
        **station,
        "distance_km": round(distance, 2),
        "required_battery_pct": round(required_pct, 2),
        "distance_score": round(distance_score, 2),
        "availability_score": availability_score,
        "charging_score": round(charging_score, 2),
        "battery_score": battery_score,
        "charger_score": charger_score,
        "guard_score": guard_score,
        "score": round(total, 2),
        "feasible": feasible,
        "availability_status": "Available" if station["available_slots"] > 0 else "Full",
    }

def rank_stations(vehicle):
    """
    Evaluate every station in O(n), then rank using a heap.
    heapq.nlargest performs ranking in O(n log k), with k=number requested.
    A complete sort is O(n log n).
    """
    evaluated = [evaluate_station(s, vehicle) for s in STATIONS]
    feasible = [x for x in evaluated if x["feasible"]]
    candidates = feasible if feasible else [x for x in evaluated if x["available_slots"] > 0]
    ranked = sorted(candidates, key=lambda x: x["score"], reverse=True)
    return evaluated, ranked

@app.get("/")
def index():
    if not session.get("verified_mobile"):
        return redirect(url_for("login"))
    return render_template("index.html", mobile=session["verified_mobile"])

@app.get("/login")
def login():
    if session.get("verified_mobile"):
        return redirect(url_for("index"))
    return render_template("login.html")

@app.post("/api/request-otp")
def request_otp():
    phone = normalize_mobile(request.get_json(force=True).get("mobile"))
    if not phone:
        return jsonify({"success": False, "message": "Enter a valid 10-digit Indian mobile number."}), 400

    otp = f"{random.randint(0, 999999):06d}"
    OTP_STORE[phone] = {"otp": otp, "expires": time.time() + OTP_EXPIRY_SECONDS}

    result = send_sms(phone, f"EV Charging Station Planner OTP: {otp}. Valid for 5 minutes.")
    response = {"success": True, "phone": phone[-10:], "mode": result["mode"]}

    # Demo mode: show OTP only because no SMS provider is configured.
    # Real mode never returns the OTP to the browser.
    if result["mode"] == "demo":
        response["demo_otp"] = otp
        response["message"] = "Demo OTP generated. Configure Twilio to send the OTP to the phone."
    elif result["mode"] == "error":
        response["success"] = False
        response["message"] = "SMS provider error. Check Twilio configuration."
        return jsonify(response), 502
    else:
        response["message"] = "OTP sent to your registered mobile number."

    return jsonify(response)

@app.post("/api/verify-otp")
def verify_otp():
    data = request.get_json(force=True)
    phone = normalize_mobile(data.get("mobile"))
    otp = str(data.get("otp", "")).strip()
    record = OTP_STORE.get(phone)

    if not phone or not record:
        return jsonify({"success": False, "message": "Request a new OTP first."}), 400
    if time.time() > record["expires"]:
        OTP_STORE.pop(phone, None)
        return jsonify({"success": False, "message": "OTP expired. Request a new OTP."}), 400
    if otp != record["otp"]:
        return jsonify({"success": False, "message": "Incorrect OTP."}), 400

    OTP_STORE.pop(phone, None)
    session["verified_mobile"] = phone
    return jsonify({"success": True, "redirect": url_for("index")})

@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify({"success": True, "redirect": url_for("login")})



@app.get("/api/stations")
def stations():
    return jsonify(STATIONS)

@app.post("/api/recommend")
def recommend():
    vehicle = request.get_json(force=True)
    evaluated, ranked = rank_stations(vehicle)
    best = ranked[0] if ranked else None

    reasons = []
    if best:
        reasons.append(f"{best['distance_km']} km from the vehicle")
        reasons.append(f"{best['available_slots']}/{best['total_slots']} slots available")
        reasons.append(f"{best['charger_type']} at {best['speed_kw']} kW")
        reasons.append(f"estimated charging time {best['charging_minutes']} minutes")
        reasons.append("guard available" if best["guard"] else "no guard currently available")

    return jsonify({
        "best": best,
        "evaluated": evaluated,
        "ranked": ranked,
        "reason": reasons,
        "algorithm": {
            "evaluation_complexity": "O(n)",
            "ranking_complexity": "O(n log n)",
            "distance_complexity": "O(1) per station",
            "data_structure": "Array/list + sorting; heap-compatible ranking"
        }
    })

@app.post("/api/reverse-geocode")
def reverse_geocode():
    data = request.get_json(force=True)
    lat, lon = data.get("lat"), data.get("lon")
    if lat is None or lon is None:
        return jsonify({"error": "lat and lon are required"}), 400

    try:
        r = requests.get(
            "https://nominatim.openstreetmap.org/reverse",
            params={"lat": lat, "lon": lon, "format": "jsonv2", "zoom": 18, "addressdetails": 1},
            headers={"User-Agent": "EV-Charging-Station-Planner/1.0 college-project"},
            timeout=8
        )
        r.raise_for_status()
        data = r.json()
        address = data.get("address", {})
        name = (
            data.get("display_name")
            or ", ".join(filter(None, [
                address.get("road"), address.get("suburb"),
                address.get("city") or address.get("town") or address.get("village"),
                address.get("state")
            ]))
            or "Unknown location"
        )
        return jsonify({"name": name, "raw": address})
    except Exception:
        return jsonify({"name": f"{float(lat):.5f}, {float(lon):.5f}", "fallback": True})



@app.post("/api/low-battery-alert")
def low_battery_alert():
    if not session.get("verified_mobile"):
        return jsonify({"success": False, "message": "Mobile verification required."}), 401

    data = request.get_json(force=True)
    battery = max(0, min(100, float(data.get("battery", 0))))
    if battery > 20:
        return jsonify({"success": False, "message": "Battery is above the low-battery threshold."}), 400

    level = int(round(battery))
    location = data.get("location", "current vehicle location")
    station = data.get("station", "nearest suitable station")
    message = (
        f"EV ALERT: Battery is {level}%. Vehicle near {location}. "
        f"Recommended charging station: {station}. Please charge soon."
    )
    result = send_sms(session["verified_mobile"], message)

    return jsonify({
        "success": True,
        "mode": result["mode"],
        "message": "Real SMS sent to the verified mobile number." if result["mode"] == "real"
                   else "SIMULATED SMS alert generated for the verified mobile number.",
        "phone": session["verified_mobile"][-10:]
    })


@app.post("/api/route")
def route():
    """Get an actual road route between the vehicle and selected station."""
    data = request.get_json(force=True)
    try:
        start_lat = float(data["start_lat"])
        start_lon = float(data["start_lon"])
        end_lat = float(data["end_lat"])
        end_lon = float(data["end_lon"])

        url = (
            "https://router.project-osrm.org/route/v1/driving/"
            f"{start_lon},{start_lat};{end_lon},{end_lat}"
        )
        response = requests.get(
            url,
            params={"overview": "full", "geometries": "geojson", "steps": "false"},
            headers={"User-Agent": "EV-Charging-Station-Planner/1.0 college-project"},
            timeout=12
        )
        response.raise_for_status()
        payload = response.json()

        if payload.get("code") != "Ok" or not payload.get("routes"):
            return jsonify({"success": False, "message": "Road route unavailable."}), 502

        route_data = payload["routes"][0]
        coordinates = route_data["geometry"]["coordinates"]

        # OSRM returns [longitude, latitude]; Leaflet expects [latitude, longitude].
        leaflet_coords = [[point[1], point[0]] for point in coordinates]

        return jsonify({
            "success": True,
            "coordinates": leaflet_coords,
            "distance_km": round(route_data["distance"] / 1000, 2),
            "duration_min": round(route_data["duration"] / 60)
        })
    except Exception as exc:
        return jsonify({"success": False, "message": str(exc)}), 502

@app.post("/api/nearest")
def nearest_station():
    """Return the geographically nearest station, plus availability details."""
    vehicle = request.get_json(force=True)
    candidates = []
    for s in STATIONS:
        item = evaluate_station(s, vehicle)
        candidates.append(item)
    # Emergency workflow needs the nearest station, not the highest DAA score.
    nearest = min(candidates, key=lambda x: x["distance_km"]) if candidates else None
    return jsonify({"station": nearest})

@app.post("/api/notify-guard")
def notify_guard():
    data = request.get_json(force=True)
    return jsonify({
        "success": True,
        "message": f"Guard at {data.get('station_name', 'selected station')} notified",
        "time": datetime.now().strftime("%H:%M:%S")
    })

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
